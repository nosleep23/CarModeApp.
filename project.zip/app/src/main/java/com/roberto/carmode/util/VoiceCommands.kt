
package com.roberto.carmode.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.ContactsContract
import androidx.core.content.ContextCompat.startActivity

fun handleVoiceCommand(ctx: Context, cmd: String) {
    val parts = cmd.trim().lowercase().split(" ")
    if (parts.isEmpty()) return
    when (parts[0]) {
        "call" -> {
            val name = parts.drop(1).joinToString(" ")
            if (name.isNotBlank()) {
                val uri = Uri.withAppendedPath(
                    ContactsContract.Contacts.CONTENT_FILTER_URI,
                    Uri.encode(name)
                )
                val intent = Intent(Intent.ACTION_VIEW).apply { data = uri }
                ctx.startActivity(intent)
            }
        }
        "navigate" -> {
            val dest = parts.drop(2).joinToString(" ")
            if (dest.isNotBlank()) {
                val uri = Uri.parse("google.navigation:q=${dest}")
                val intent = Intent(Intent.ACTION_VIEW, uri)
                ctx.startActivity(intent)
            }
        }
    }
}
