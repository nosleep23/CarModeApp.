
package com.roberto.carmode

import android.Manifest
import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts

@Composable
fun GaugesScreen() {
    val ctx = LocalContext.current
    var speed by remember { mutableStateOf(0f) }
    var heading by remember { mutableStateOf(0f) }

    val locationPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) {}

    LaunchedEffect(Unit) {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) !=
            android.content.pm.PackageManager.PERMISSION_GRANTED) {
            locationPermissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
        } else {
            startLocationUpdates(ctx) { spd -> speed = spd }
        }
        startCompass(ctx) { deg -> heading = deg }
    }

    Column(
        Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Speed: ${'$'}{String.format("%.1f", speed)} km/h", fontSize = 28.sp)
        Spacer(Modifier.height(12.dp))
        Text("Heading: ${'$'}{heading.toInt()}°", fontSize = 28.sp)
    }
}

fun startLocationUpdates(ctx: Context, onSpeed: (Float) -> Unit) {
    val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    val listener = LocationListener { loc: Location? ->
        if (loc != null && loc.hasSpeed()) {
            val kmh = loc.speed * 3.6f
            onSpeed(kmh)
        }
    }
    try {
        lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, listener)
    } catch (_: SecurityException) {}
}

fun startCompass(ctx: Context, onHeading: (Float) -> Unit) {
    val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    val acc = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    val mag = sm.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)
    val gravity = FloatArray(3)
    val geomag = FloatArray(3)
    val rotMat = FloatArray(9)
    val orient = FloatArray(3)

    val listener = object : SensorEventListener {
        override fun onSensorChanged(event: SensorEvent) {
            when (event.sensor.type) {
                Sensor.TYPE_ACCELEROMETER -> System.arraycopy(event.values, 0, gravity, 0, 3)
                Sensor.TYPE_MAGNETIC_FIELD -> System.arraycopy(event.values, 0, geomag, 0, 3)
            }
            if (SensorManager.getRotationMatrix(rotMat, null, gravity, geomag)) {
                SensorManager.getOrientation(rotMat, orient)
                val azimuth = Math.toDegrees(orient[0].toDouble()).toFloat()
                val deg = (azimuth + 360) % 360
                onHeading(deg)
            }
        }
        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    }
    sm.registerListener(listener, acc, SensorManager.SENSOR_DELAY_UI)
    sm.registerListener(listener, mag, SensorManager.SENSOR_DELAY_UI)
}
