package com.roberto.carmode.player

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.platform.LocalContext

@Composable
fun PlayerScreen() {
    val ctx = LocalContext.current
    var picked by remember { mutableStateOf<Uri?>(null) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) picked = uri
    }
    val player = remember {
        ExoPlayer.Builder(ctx).build()
    }
    DisposableEffect(Unit) {
        onDispose { player.release() }
    }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Music", androidx.compose.ui.text.font.FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onClick = { launcher.launch(arrayOf("audio/*")) }) { Text("Pick audio") }
            Button(onClick = {
                if (picked != null) {
                    player.setMediaItem(MediaItem.fromUri(picked!!))
                    player.prepare()
                    player.play()
                }
            }) { Text("Play") }
            Button(onClick = { player.pause() }) { Text("Pause") }
        }
        if (picked != null) Text("Selected: " + picked.toString())
    }
}
