package com.roberto.carmode

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import android.speech.RecognizerIntent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.roberto.carmode.player.PlayerScreen
import com.roberto.carmode.theme.AppTheme
import com.roberto.carmode.util.askSpeech
import com.roberto.carmode.util.hasPermission

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AppTheme {
                val nav = rememberNavController()
                Surface(Modifier.fillMaxSize()) {
                    NavHost(navController = nav, startDestination = "home") {
                        composable("home") { HomeScreen(nav) }
                        composable("phone") { PhoneScreen() }
                        composable("messages") { MessagesScreen() }
                        composable("player") { PlayerScreen() }
                        composable("navigate") { NavigateScreen() }
                        composable("gauges") { GaugesScreen() }
                        composable("settings") { SettingsScreen() }
                    }
                }
            }
        }
    }
}

@Composable
private fun HomeScreen(nav: NavHostController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text("CarMode", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        TileGrid(
            tiles = listOf(
                TileData("Phone") { nav.navigate("phone") },
                TileData("Music") { nav.navigate("player") },
                TileData("Maps") { nav.navigate("navigate") },
                TileData("Messages") { nav.navigate("messages") },
                TileData("Gauges") { nav.navigate("gauges") },
                TileData("Settings") { nav.navigate("settings") },
                    TileData("Voice") { VoiceDialog() },
            )
        )
    }
}

data class TileData(val label: String, val action: () -> Unit)

@Composable
fun TileGrid(tiles: List<TileData>) {
    Column(Modifier.fillMaxSize()) {
        for (row in tiles.chunked(3)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                for (tile in row) {
                    Tile(tile)
                }
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}

@Composable
fun Tile(tile: TileData) {
    Surface(
        tonalElevation = 2.dp,
        shape = MaterialTheme.shapes.large,
        modifier = Modifier
            .weight(1f)
            .height(110.dp)
            .clickable { tile.action() }
    ) {
        Box(Modifier.fillMaxSize().padding(16.dp), contentAlignment = Alignment.Center) {
            Text(tile.label, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
fun PhoneScreen() {
    val ctx = LocalContext.current
    val hasContacts = ctx.hasPermission(Manifest.permission.READ_CONTACTS)
    val launcher = remember {
        (ctx as ComponentActivity).registerForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) {}
    }
    LaunchedEffect(Unit) {
        if (!hasContacts) launcher.launch(Manifest.permission.READ_CONTACTS)
    }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Phone", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        if (!hasContacts) {
            Text("Grant Contacts permission to show favorites.")
        } else {
            FavoriteContactsList { number ->
                val callIntent = Intent(Intent.ACTION_CALL, Uri.parse("tel:$number"))
                if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.CALL_PHONE)
                    != PackageManager.PERMISSION_GRANTED
                ) {
                    (ctx as ComponentActivity).registerForActivityResult(
                        ActivityResultContracts.RequestPermission()
                    ) {}.launch(Manifest.permission.CALL_PHONE)
                } else {
                    ctx.startActivity(callIntent)
                }
            }
        }
    }
}

@Composable
fun FavoriteContactsList(onCall: (String) -> Unit) {
    val ctx = LocalContext.current
    var contacts by remember { mutableStateOf(listOf<Pair<String, String>>()) }
    LaunchedEffect(Unit) {
        val cr = ctx.contentResolver
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER,
            ContactsContract.Contacts.STARRED
        )
        val cursor = cr.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            projection,
            ContactsContract.Contacts.STARRED + "=?",
            arrayOf("1"),
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " ASC"
        )
        val out = mutableListOf<Pair<String, String>>()
        cursor?.use {
            val nameIdx = it.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
            val numIdx = it.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER)
            while (it.moveToNext()) {
                out += it.getString(nameIdx) to it.getString(numIdx)
            }
        }
        contacts = out
    }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(contacts) { (name, number) ->
            Surface(tonalElevation = 2.dp, shape = MaterialTheme.shapes.large,
                modifier = Modifier.fillMaxWidth().clickable { onCall(number) }) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(name, fontSize = 20.sp, modifier = Modifier.weight(1f))
                    Text(number, fontSize = 16.sp)
                }
            }
        }
    }
}

@Composable
fun MessagesScreen() {
    val ctx = LocalContext.current
    var number by remember { mutableStateOf("") }
    var body by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Messages (compose only)", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        OutlinedTextField(value = number, onValueChange = { number = it }, label = { Text("Phone number") }, singleLine = true)
        OutlinedTextField(value = body, onValueChange = { body = it }, label = { Text("Message") }, singleLine = false)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onClick = {
                // Open default SMS app with pre-filled message
                val uri = Uri.parse("smsto:${number}")
                val intent = Intent(Intent.ACTION_SENDTO, uri).apply {
                    putExtra("sms_body", body)
                }
                ctx.startActivity(intent)
            }) { Text("Send") }
            Button(onClick = {
                ctx.askSpeech { text -> body = text }
            }) { Text("Dictate") }
        }
    }
}

@Composable
fun NavigateScreen() {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Navigation shortcuts", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("Opens your preferred maps app (Google Maps, Waze, OsmAnd).", fontSize = 14.sp)
        Button(onClick = {
            val uri = Uri.parse("geo:0,0?q=home")
            val i = Intent(Intent.ACTION_VIEW, uri)
            ctx.startActivity(i)
        }) { Text("Go Home") }
        Button(onClick = {
            val uri = Uri.parse("google.navigation:q=work")
            val i = Intent(Intent.ACTION_VIEW, uri)
            ctx.startActivity(i)
        }) { Text("Go to Work") }
        Button(onClick = {
            val uri = Uri.parse("google.navigation:q=fuel+station")
            val i = Intent(Intent.ACTION_VIEW, uri)
            ctx.startActivity(i)
        }) { Text("Find Fuel") }
    }
}

@Composable
fun GaugesScreen() {
    val ctx = LocalContext.current
    var speed by remember { mutableStateOf(0f) }
    var heading by remember { mutableStateOf(0f) }
    // Collect flows when screen is visible
    LaunchedEffect(Unit) {
        if (ctx.hasPermission(Manifest.permission.ACCESS_FINE_LOCATION)) {
            ctx.speedFlow().collect { speed = it }
        }
    }
    LaunchedEffect(Unit) {
        ctx.headingFlow().collect { heading = it }
    }
    Column(
        Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(24.dp)
    ) {
        Text("Gauges", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Surface(tonalElevation = 4.dp, shape = MaterialTheme.shapes.extraLarge) {
            Box(Modifier.fillMaxWidth().height(160.dp), contentAlignment = Alignment.Center) {
                Text("${'$'}{speed.toInt()} km/h", fontSize = 56.sp, fontWeight = FontWeight.ExtraBold)
            }
        }
        Surface(tonalElevation = 4.dp, shape = MaterialTheme.shapes.extraLarge) {
            Box(Modifier.fillMaxWidth().height(120.dp), contentAlignment = Alignment.Center) {
                Text("Heading: ${'$'}{heading.toInt()}°", fontSize = 28.sp, fontWeight = FontWeight.SemiBold)
            }
        }
        if (!ctx.hasPermission(Manifest.permission.ACCESS_FINE_LOCATION)) {
            Text("Location permission required for speed.", color = MaterialTheme.colorScheme.error)
        }
    }
}
}

@Composable
fun SettingsScreen() {
        var dark by remember { mutableStateOf(false) }
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Settings", fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Dark mode")
                Spacer(Modifier.width(12.dp))
                Switch(checked = dark, onCheckedChange = { dark = it })
            }
        Text("Tip: Add favorite contacts ★ in your Contacts app to show them in Phone screen.")
        Text("Enable microphone and contacts permissions for best experience.")
    }
}


@Composable
fun VoiceDialog() {
    val ctx = LocalContext.current
    var last by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(Unit) {
        ctx.askSpeech { text ->
            last = text
            // naive parsing
            val lower = text.lowercase()
            when {
                lower.startsWith("call ") || lower.startsWith("apelează ") -> {
                    // Open dialer with number/name (best-effort; name lookup is complex => open dialer only)
                    val chunk = text.substringAfter(" ").trim()
                    val i = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${chunk}"))
                    ctx.startActivity(i)
                }
                lower.startsWith("navigate to ") or lower.startswith("navighează la ") -> {
                    val q = text.split(" ", limit=3).last().trim()
                    val uri = Uri.parse("google.navigation:q=" + Uri.encode(q))
                    ctx.startActivity(Intent(Intent.ACTION_VIEW, uri))
                }
                lower.startsWith("play ") || lower.startsWith("redă ") -> {
                    // Send user to player screen
                    // In this simple demo we just open a file picker via PlayerScreen manual action
                }
            }
        }
    }
    AlertDialog(
        onDismissRequest = {},
        confirmButton = { TextButton(onClick = {}) { Text("OK") } },
        title = { Text("Voice") },
        text = { Text(last ?: "Ascult...") }
    )
}
