package com.roberto.carmode.util

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.speech.RecognizerIntent
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

fun Context.hasPermission(p: String): Boolean =
    ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

fun Context.askSpeech(onResult: (String) -> Unit) {
    val activity = this as ComponentActivity
    val launcher = activity.registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { res ->
        val data = res.data
        val results = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
        if (!results.isNullOrEmpty()) onResult(results[0])
    }
    val intent = RecognizerIntent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
    }
    launcher.launch(intent)
}


import android.location.Location
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.content.Context.SENSOR_SERVICE
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.callbackFlow

fun Context.speedFlow() = callbackFlow<Float> {
    val client = com.google.android.gms.location.LocationServices.getFusedLocationProviderClient(this@speedFlow)
    val req = com.google.android.gms.location.LocationRequest.Builder(
        com.google.android.gms.location.Priority.PRIORITY_HIGH_ACCURACY, 1000L
    ).setMinUpdateIntervalMillis(500L).build()
    val cb = object : com.google.android.gms.location.LocationCallback() {
        override fun onLocationResult(res: com.google.android.gms.location.LocationResult) {
            val loc: Location? = res.lastLocation
            if (loc != null) {
                // m/s -> km/h
                trySend((loc.speed * 3.6f).coerceAtLeast(0f))
            }
        }
    }
    client.requestLocationUpdates(req, cb, mainLooper)
    awaitClose { client.removeLocationUpdates(cb) }
}

fun Context.headingFlow() = callbackFlow<Float> {
    val sm = getSystemService(SENSOR_SERVICE) as SensorManager
    val accel = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    val magnet = sm.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)
    val gravity = FloatArray(3)
    val geomag = FloatArray(3)
    val Rm = FloatArray(9)
    val I = FloatArray(9)
    val listener = object : SensorEventListener {
        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        override fun onSensorChanged(event: SensorEvent) {
            when(event.sensor.type) {
                Sensor.TYPE_ACCELEROMETER -> {
                    System.arraycopy(event.values, 0, gravity, 0, 3)
                }
                Sensor.TYPE_MAGNETIC_FIELD -> {
                    System.arraycopy(event.values, 0, geomag, 0, 3)
                }
            }
            if (SensorManager.getRotationMatrix(Rm, I, gravity, geomag)) {
                val orientation = FloatArray(3)
                SensorManager.getOrientation(Rm, orientation)
                var azimuth = Math.toDegrees(orientation[0].toDouble()).toFloat()
                if (azimuth < 0) azimuth += 360f
                trySend(azimuth)
            }
        }
    }
    sm.registerListener(listener, accel, SensorManager.SENSOR_DELAY_UI)
    sm.registerListener(listener, magnet, SensorManager.SENSOR_DELAY_UI)
    awaitClose { sm.unregisterListener(listener) }
}
