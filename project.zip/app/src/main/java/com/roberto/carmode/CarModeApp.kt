package com.roberto.carmode

import android.app.Application

class CarModeApp : Application()
